# Aplicativo de Bate-papo básico usando Flask, Socket.IO e mongoDB.

Tutorial do Canal do YouTube: __Indian Pythonista__.
Basic Chat Application | Chat Application using Flask, Socket.IO & mongoDB.
